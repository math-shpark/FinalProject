package mc.sn.cocoa.service;

public interface MemberService {

}