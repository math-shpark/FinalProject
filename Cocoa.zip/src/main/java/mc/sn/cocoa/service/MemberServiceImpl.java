package mc.sn.cocoa.service;

public class MemberServiceImpl {

}
