package mc.sn.cocoa.controller;

public interface MemberController {

}
