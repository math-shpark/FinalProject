package mc.sn.cocoa.controller;

public class MemberControllerImpl {

}
