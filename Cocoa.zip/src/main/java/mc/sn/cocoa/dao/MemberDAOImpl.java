package mc.sn.cocoa.dao;

public class MemberDAOImpl {

}
